This app uses the **rmarkdown** package to compile a report template to PDF/HTML/Word,
which we can download by clicking a button. Note we switched the working dir
to a temporary dir, to avoid the possibility that we do not have write
permission on the server.
