A simple Shiny app that displays eruption data for the Google Trend Index app. Featured on the front page of the [Shiny Dev Center](http://shiny.rstudio.com).
